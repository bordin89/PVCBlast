# Define version number.
module SequenceServer
  VERSION = '1.0.9'
end
